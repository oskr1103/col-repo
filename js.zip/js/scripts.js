// if (localStorage.getItem("colpensionesAcc") != null) {
//   $("html")[0].className = localStorage.getItem("colpensionesAcc");
// }

// function tamañoLetra() {
//   if (localStorage.getItem("colpensionesAcc") != null) {
//     return;
//   }
//   size = $(".zoom").css("font-size");
//   size = parseInt(size, 10);
//   $(".tamaño-actual").text(size);
//   localStorage.setItem("colpensionesAcc", $(".zoom").css("font-size"));
// }
